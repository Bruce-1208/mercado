"use strict";

(function () {
  let mutationTimer = null;

  function text(selector) {
    const node = document.querySelector(selector);
    return String(node?.textContent || node?.getAttribute?.("content") || "").replace(/\s+/g, " ").trim();
  }

  function itemId() {
    const match = location.href.match(/\/offer\/(\d{5,})\.html/i)
      || location.href.match(/[?&](?:offerId|offer_id|itemId)=(\d{5,})/i);
    return match ? match[1] : "";
  }

  function itemIdFromValue(value) {
    const source = String(value || "");
    const match = source.match(/\/offer\/(\d{5,})(?:\.html)?/i)
      || source.match(/[?&](?:offerId|offer_id|itemId)=(\d{5,})/i)
      || source.match(/(?:object_id@|offer_)(\d{5,})/i)
      || source.match(/_(\d{5,})$/);
    return match ? match[1] : "";
  }

  function absoluteUrl(value) {
    const source = String(value || "").trim();
    if (!source) return "";
    try { return new URL(source, location.href).href; }
    catch (_) { return ""; }
  }

  function absoluteImage(value) {
    let url = String(value || "").trim().replace(/&amp;/g, "&");
    if (url.startsWith("//")) url = `https:${url}`;
    if (!/^https?:\/\//i.test(url)) return "";
    try {
      const parsed = new URL(url);
      if (/(^|\.)alicdn\.com$/i.test(parsed.hostname)) {
        parsed.pathname = parsed.pathname.replace(/\.(jpe?g|png|webp)(?:_[^/?#]*)+$/i, ".$1");
        return parsed.href;
      }
    } catch (_) {}
    return url;
  }

  function collectImages() {
    const result = [];
    const add = value => {
      const url = absoluteImage(value);
      if (!url || /(?:icon|logo|avatar|sprite|\.svg(?:[?#]|$))/i.test(url) || result.includes(url)) return;
      result.push(url);
    };
    document.querySelectorAll([
      "#gallery img.preview-img", "#gallery .thumbnail img", "#gallery img",
      ".detail-gallery img", ".od-gallery img", ".mod-detail-gallery img"
    ].join(",")).forEach(image => {
      add(image.dataset.src || image.dataset.lazyloadSrc || image.currentSrc || image.src);
    });
    if (!result.length) add(document.querySelector("meta[property='og:image']")?.content);
    return result.slice(0, 20);
  }

  function collectProperties() {
    const rows = [];
    const seen = new Set();
    const add = (name, value) => {
      name = String(name || "").replace(/\s+/g, " ").trim();
      value = String(value || "").replace(/\s+/g, " ").trim();
      const key = `${name}:${value}`;
      if (!name || !value || seen.has(key)) return;
      seen.add(key);
      rows.push({name: name.slice(0, 120), value: value.slice(0, 500)});
    };
    document.querySelectorAll("#productAttributes li, .od-pc-attribute-list li, .detail-attributes li").forEach(row => {
      const children = row.querySelectorAll("span, div");
      if (children.length >= 2) add(children[0].textContent, children[children.length - 1].textContent);
      else {
        const parts = String(row.textContent || "").split(/[：:]/, 2);
        if (parts.length === 2) add(parts[0], parts[1]);
      }
    });
    document.querySelectorAll("#productAttributes dt, .detail-attributes dt, .od-pc-attribute-list dt").forEach(node => add(node.textContent, node.nextElementSibling?.textContent));
    return rows.slice(0, 100);
  }

  function numericPrice(skus) {
    const prices = skus.map(row => row.price).filter(value => Number.isFinite(value) && value > 0);
    if (prices.length) return Math.min(...prices);
    const raw = text("#productPrice [class*='price']") || text("#productPrice")
      || text("meta[property='og:price:amount']");
    const match = raw.replace(/,/g, "").match(/(?:¥|￥)\s*(\d+(?:\.\d+)?)/)
      || raw.trim().match(/^(\d+(?:\.\d+)?)$/);
    return match ? Number(match[1]) : null;
  }

  // Keep supplier detail extraction in one place.  The AI weight/price flow
  // reads these values from the React SKU and package modules because the new
  // 1688 shell no longer renders every fact as ordinary page text.  Product
  // collection must use the same evidence, otherwise the two entry points
  // persist different weight/dimension results for the same offer.
  function aiWeightPriceNumber(value) {
    const match = String(value || "").replace(/,/g, "").match(/-?\d+(?:\.\d+)?/);
    return match ? Number(match[0]) : null;
  }

  function aiWeightPriceDecode(value) {
    const box = document.createElement("textarea");
    box.innerHTML = String(value || "");
    return String(box.value || "").replace(/>/g, " / ").replace(/\s+/g, " ").trim();
  }

  function aiWeightPriceVariationAttributes(label) {
    return String(label || "").split(/\s*\/\s*/).map((part, index) => {
      const pieces = part.split(/[：:]/, 2).map(value => value.trim());
      const name = pieces.length > 1 ? pieces[0] : `规格${index + 1}`;
      const value_name = pieces.length > 1 ? pieces[1] : pieces[0];
      return name && value_name ? {name, value_name} : null;
    }).filter(Boolean).slice(0, 20);
  }

  function aiWeightPriceConvertWeight(value, unit = "g") {
    const number = aiWeightPriceNumber(value);
    if (!Number.isFinite(number) || number <= 0) return null;
    const normalized = String(unit || "g").toLowerCase();
    if (/^(kg|公斤|千克)$/.test(normalized)) return number * 1000;
    if (/^(斤)$/.test(normalized)) return number * 500;
    return /^(g|克)$/.test(normalized) ? number : null;
  }

  function aiWeightPriceParseWeight(value, defaultUnit = "g") {
    const raw = String(value || "").replace(/,/g, "");
    const match = raw.match(/(\d+(?:\.\d+)?)\s*(kg|公斤|千克|g|克|斤)(?![A-Za-z0-9])/i);
    if (match) return aiWeightPriceConvertWeight(match[1], match[2]);
    return /^\s*\d+(?:\.\d+)?\s*$/.test(raw) ? aiWeightPriceConvertWeight(raw, defaultUnit) : null;
  }

  function aiWeightPriceParseDimensions(value) {
    const raw = String(value || "").replace(/,/g, ".").replace(/\s+/g, " ").trim();
    const labelled = /(?:包装尺寸|外箱尺寸|商品尺寸|尺寸|长\s*[x×*]\s*宽\s*[x×*]\s*高|长宽高)[^\d]{0,24}(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*(mm|cm|m)?\b/i.exec(raw);
    const plain = /(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*(mm|cm|m)\b/i.exec(raw);
    const match = labelled || plain;
    if (!match) return null;
    const unit = String(match[4] || "cm").toLowerCase();
    const convert = number => unit === "mm" ? number / 10 : unit === "m" ? number * 100 : number;
    const values = [convert(Number(match[1])), convert(Number(match[2])), convert(Number(match[3]))];
    if (!values.every(value => Number.isFinite(value) && value > 0)) return null;
    return {
      package_length_cm: values[0], package_width_cm: values[1], package_height_cm: values[2],
      dimensions_display: `${match[1]} × ${match[2]} × ${match[3]} ${unit}`
    };
  }

  function aiWeightPriceStructuredMetrics(item) {
    if (!item || typeof item !== "object") return null;
    const valueFor = keys => {
      for (const key of keys) {
        if (item[key] !== undefined && item[key] !== null && item[key] !== "") {
          return {key, value: item[key]};
        }
      }
      return null;
    };
    const rawWeight = valueFor(["weight_g", "weightG", "weightKg", "grossWeight", "packageWeight", "weight"]);
    const length = valueFor(["package_length_cm", "packageLengthCm", "lengthCm", "lengthMm", "length"]);
    const width = valueFor(["package_width_cm", "packageWidthCm", "widthCm", "widthMm", "width"]);
    const height = valueFor(["package_height_cm", "packageHeightCm", "heightCm", "heightMm", "height"]);
    const result = {};
    if (rawWeight) {
      result.weight_g = aiWeightPriceParseWeight(rawWeight.value, /kg|公斤|千克/i.test(rawWeight.key) ? "kg" : item.weightUnit || "g");
    }
    const dimensions = [length, width, height];
    if (dimensions.every(Boolean)) {
      const unit = dimensions.some(entry => /mm/i.test(entry.key)) ? "mm"
        : String(item.lengthUnit || item.dimensionUnit || item.sizeUnit || "cm").toLowerCase();
      const convert = entry => {
        const match = String(entry.value).replace(/,/g, "").trim().match(/^(\d+(?:\.\d+)?)\s*(mm|cm|m|毫米|厘米|米)?$/i);
        if (!match) return null;
        const valueUnit = String(match[2] || unit).toLowerCase();
        if (!["mm", "cm", "m", "毫米", "厘米", "米"].includes(valueUnit)) return null;
        const number = Number(match[1]);
        if (!Number.isFinite(number) || number <= 0) return null;
        return ["mm", "毫米"].includes(valueUnit) ? number / 10 : ["m", "米"].includes(valueUnit) ? number * 100 : number;
      };
      result.package_length_cm = convert(length);
      result.package_width_cm = convert(width);
      result.package_height_cm = convert(height);
      if ([result.package_length_cm, result.package_width_cm, result.package_height_cm]
        .every(value => Number.isFinite(value) && value > 0)) {
        result.dimensions_display = `${result.package_length_cm} × ${result.package_width_cm} × ${result.package_height_cm} cm`;
      }
    }
    const parsedText = aiWeightPriceParseDimensions(JSON.stringify(item));
    if (parsedText && !result.dimensions_display) Object.assign(result, parsedText);
    return Object.keys(result).length ? result : null;
  }

  function aiWeightPriceStableArray(arrays) {
    const valid = arrays.filter(Boolean).filter(list => list.length);
    if (!valid.length) return [];
    const largest = Math.max(...valid.map(list => list.length));
    const choices = new Map(valid.filter(list => list.length === largest)
      .map(list => [JSON.stringify(list), list]));
    return choices.size === 1 ? [...choices.values()][0] : [];
  }

  function aiWeightPriceDomRows() {
    const rows = [];
    document.querySelectorAll(".od-pc-sku-table, .sku-table").forEach(table => {
      const headers = [...table.querySelectorAll("thead th, tr:first-child th")].map(cell => cell.textContent.trim());
      for (const row of table.querySelectorAll("tr")) {
        const cells = [...row.querySelectorAll("td")].map(cell => cell.textContent.replace(/\s+/g, " ").trim());
        if (cells.length < 2 || rows.length >= 200) continue;
        const priceIndex = headers.findIndex(value => /价格|单价/.test(value));
        const currencyIndex = cells.findIndex(value => /^(?:¥|￥)\s*\d/.test(value));
        const index = priceIndex >= 0 ? priceIndex : currencyIndex;
        if (index < 0) continue;
        const price = aiWeightPriceNumber(cells[index]);
        const attributes = cells.flatMap((value, i) => {
          const header = headers[i] || "";
          if (!value || i === index || /价格|单价|库存|数量|重量|毛重|净重|尺寸信息|包装|操作/.test(header)) return [];
          if (!header && i >= index) return [];
          return [{name: header || `规格${i + 1}`, value_name: value}];
        });
        if (!attributes.length) continue;
        const stockIndex = headers.findIndex(value => /库存|可售数量/.test(value));
        const stock = stockIndex >= 0 && /^\d+$/.test(cells[stockIndex] || "") ? Number(cells[stockIndex]) : null;
        rows.push({id: row.getAttribute("data-sku-id") || "", sku_id: row.getAttribute("data-sku-id") || "",
          label: attributes.map(item => `${item.name}:${item.value_name}`).join(" / "),
          attribute_combinations: attributes, price: price > 0 ? price : null,
          available_quantity: stock, price_text: cells[index], raw_text: cells.join(" "), raw_weight: ""});
      }
    });
    return rows;
  }

  function aiWeightPriceReactSkus(pageData) {
    const selection = document.querySelector("#skuSelection[data-module='od_sku_selection']")
      || document.querySelector("[data-module='od_sku_selection']");
    if (!selection) return [];
    const sets = pageData.sku_sets || [];
    const normalized = sets.map(list => list.map(item => {
      const label = aiWeightPriceDecode(item.specAttrs);
      const price = [item.discountPrice, item.currentPrice, item.priceNum, item.price]
        .find(value => /^\d+(?:\.\d+)?$/.test(String(value ?? "").trim()) && Number(value) > 0);
      const stock = item.canBookCount ?? item.availableQuantity ?? item.stock ?? item.quantity;
      const image = item.imageUrl ?? item.imgUrl ?? item.image ?? item.pictureUrl;
      return {
        id: String(item.skuId || ""),
        seller_sku: String(item.skuCode ?? item.sku ?? item.sellerSku ?? ""),
        label,
        attribute_combinations: aiWeightPriceVariationAttributes(label),
        price: aiWeightPriceNumber(price),
        price_text: price === undefined ? "" : `¥${price}`,
        available_quantity: stock !== undefined && stock !== null && stock !== "" && Number.isFinite(Number(stock)) ? Number(stock) : null,
        image_url: typeof image === "string" ? absoluteImage(image) : "",
        label_weight: String(label).match(/(?:重量|毛重|净重)?[^\d]{0,8}(\d+(?:\.\d+)?)\s*(kg|公斤|千克|g|克|斤)\b/i)?.[0] || ""
      };
    }).filter(item => /^\d+$/.test(item.id) && item.label)
      .sort((a, b) => a.id.localeCompare(b.id))).filter(list => list.length);
    const selected = aiWeightPriceStableArray(normalized);
    return selected.map(item => ({
      id: item.id, sku_id: item.id, seller_sku: item.seller_sku,
      label: item.label, attribute_combinations: item.attribute_combinations,
      price: item.price, price_text: item.price_text,
      available_quantity: item.available_quantity, image_url: item.image_url,
      raw_weight: item.label_weight, raw_text: item.label
    }));
  }

  function aiWeightPricePackMetrics(pageData) {
    const pack = document.querySelector("#productPackInfo[data-module='od_product_pack_info']")
      || document.querySelector("[data-module='od_product_pack_info']");
    if (!pack) return {byId: new Map(), common: null};
    const arrays = pageData.pack_sets || [];
    const normalizedSets = arrays.map(list => list.map(item => ({
      id: String(item.skuId || item.id || ""), metrics: aiWeightPriceStructuredMetrics(item)
    })).filter(item => item.metrics));
    const selected = aiWeightPriceStableArray(normalizedSets);
    const byId = new Map(selected.filter(item => item.id).map(item => [item.id, item.metrics]));
    const common = selected.length === 1 && !selected[0].id ? selected[0].metrics : null;
    // Some builds expose one common package object in a separate array.
    const commonValues = arrays.flatMap(list => list.length === 1 ? list : [])
      .filter(item => item && typeof item === "object" && !item.skuId && !item.id)
      .map(aiWeightPriceStructuredMetrics).filter(Boolean);
    if (!common && commonValues.length) {
      const unique = new Map(commonValues.map(item => [JSON.stringify(item), item]));
      if (unique.size === 1) return {byId, common: [...unique.values()][0]};
    }
    return {byId, common};
  }

  function aiWeightPriceMergeMetrics(row, metrics) {
    const result = {...row};
    const labelDimensions = aiWeightPriceParseDimensions(`${row.label || ""} ${row.raw_text || ""}`);
    const combined = {...(labelDimensions || {}), ...(metrics || {})};
    if (combined.weight_g) result.raw_weight = `${combined.weight_g}g`;
    result.weight_g = combined.weight_g || aiWeightPriceParseWeight(result.raw_weight) || null;
    if (combined.package_length_cm && combined.package_width_cm && combined.package_height_cm) {
      result.package_length_cm = combined.package_length_cm;
      result.package_width_cm = combined.package_width_cm;
      result.package_height_cm = combined.package_height_cm;
      result.dimensions_display = combined.dimensions_display;
    }
    return result;
  }

  function aiWeightPriceDetailFacts(pageData) {
    const rows = aiWeightPriceReactSkus(pageData);
    const sourceRows = rows.length ? rows : aiWeightPriceDomRows();
    const pack = aiWeightPricePackMetrics(pageData);
    const merged = sourceRows.map(row => aiWeightPriceMergeMetrics(row, pack.byId.get(String(row.id)) || pack.common));
    const commonMetric = key => {
      if (!merged.length) return pack.common?.[key] ?? null;
      const values = merged.map(row => row[key]);
      return values.every(value => Number.isFinite(value) && value > 0 && value === values[0]) ? values[0] : null;
    };
    const metrics = Object.fromEntries(["weight_g", "package_length_cm", "package_width_cm", "package_height_cm"]
      .map(key => [key, commonMetric(key)]));
    const complete = [metrics.package_length_cm, metrics.package_width_cm, metrics.package_height_cm].every(value => value > 0);
    metrics.dimensions_display = complete ? `${metrics.package_length_cm} × ${metrics.package_width_cm} × ${metrics.package_height_cm} cm` : "";
    if (complete) metrics.volumetric_weight_kg = Number((metrics.package_length_cm * metrics.package_width_cm * metrics.package_height_cm / 6000).toFixed(4));
    return {skus: merged, raw_weight: metrics.weight_g ? `${metrics.weight_g}g` : "", ...metrics};
  }

  async function readPageData() {
    const response = await chrome.runtime.sendMessage({type: "READ_1688_PAGE_DATA"});
    if (!response?.ok || !response.data || response.data.offer_id !== itemId()) {
      throw new Error(response?.error || "1688商品数据尚未加载或页面已切换，请刷新详情页后重试");
    }
    return response.data;
  }

  function listCardCandidate(card) {
    const link = card.matches("a[href]")
      ? card
      : card.querySelector([
        "a[href*='/offer/']",
        "a[href*='offerId=']",
        "a[data-key-value*='offer_']",
        "a[href]"
      ].join(","));
    const rawUrl = card.getAttribute("href") || link?.getAttribute("href") || "";
    const dataValues = [
      rawUrl,
      card.getAttribute("data-renderkey"),
      card.getAttribute("data-offer-id"),
      link?.getAttribute("data-aplus-report"),
      link?.getAttribute("data-key-value")
    ];
    const sourceItemId = dataValues.map(itemIdFromValue).find(Boolean) || "";
    if (!sourceItemId) return null;

    const sourceUrl = absoluteUrl(rawUrl) || `https://detail.1688.com/offer/${sourceItemId}.html`;
    const titleNode = card.querySelector(".title-text div, .title-text, [class*='title']");
    const imageNode = card.querySelector("img.main-img, .main-img, img[src*='alicdn'], img[data-src*='alicdn'], img");
    const title = String(
      titleNode?.textContent
      || link?.getAttribute("title")
      || link?.getAttribute("aria-label")
      || imageNode?.getAttribute("alt")
      || ""
    ).replace(/\s+/g, " ").trim();
    if (!title) return null;

    const priceText = String(
      card.querySelector(".price-item, [class*='price']")?.textContent || ""
    ).replace(/,/g, "");
    const priceMatch = priceText.match(/\d+(?:\.\d+)?/);
    const image = absoluteImage(
      imageNode?.currentSrc
      || imageNode?.src
      || imageNode?.dataset?.src
      || imageNode?.dataset?.lazyloadSrc
    );
    return {
      source_platform: "1688",
      source_item_id: sourceItemId,
      source_url: sourceUrl,
      final_url: sourceUrl,
      title,
      price: priceMatch ? Number(priceMatch[0]) : null,
      currency_id: "CNY",
      main_image_url: image,
      images: image ? [image] : [],
      properties: [],
      description_text: "",
      scrape_status: "partial",
      error_message: "1688 列表页快速采集：详情、规格和重量尺寸待补充",
      collected_at: new Date().toISOString()
    };
  }

  async function extractProductSnapshot() {
    const sourceItemId = itemId();
    const title = text("#productTitle .title-content h1") || text("#productTitle h1") || text(".mod-detail-title h1") || text("h1.d-title");
    if (!sourceItemId || !title) throw new Error("未识别到 1688 商品编号或标题，请打开商品详情页后重试");
    const images = collectImages();
    const properties = collectProperties();
    const pageData = await readPageData();
    const detailFacts = aiWeightPriceDetailFacts(pageData);
    const variations = detailFacts.skus;
    if (!images.length) throw new Error("1688商品主图尚未加载，已停止采集");
    if (document.querySelector("#skuSelection") && !variations.length) throw new Error("1688商品规格尚未加载，已停止采集");
    if (sourceItemId !== itemId()) throw new Error("1688页面商品已切换，请重新采集");
    const descriptionNode = document.querySelector("#desc-lazyload-container, .detail-desc-module, #description");
    const description = String(descriptionNode?.innerText || "").replace(/\s+/g, " ").trim().slice(0, 30000);
    const dimensionsComplete = [
      detailFacts.package_length_cm, detailFacts.package_width_cm, detailFacts.package_height_cm
    ].every(value => Number.isFinite(Number(value)) && Number(value) > 0);
    const weightComplete = Boolean(detailFacts.weight_g) || (variations.length > 0 && variations.every(row => row.weight_g > 0));
    const allDimensionsComplete = dimensionsComplete || (variations.length > 0 && variations.every(row =>
      [row.package_length_cm, row.package_width_cm, row.package_height_cm].every(value => value > 0)));
    const errors = [];
    if (!weightComplete) errors.push("未读取到完整的1688规格重量");
    if (!allDimensionsComplete) errors.push("未读取到完整的1688规格包装尺寸");
    return {
      source_platform: "1688",
      source_item_id: sourceItemId,
      source_url: location.href,
      final_url: location.href,
      title,
      price: numericPrice(variations),
      currency_id: "CNY",
      main_image_url: images[0] || text("meta[property='og:image']"),
      images,
      properties,
      variations,
      description_text: description,
      weight_g: detailFacts.weight_g,
      package_length_cm: detailFacts.package_length_cm,
      package_width_cm: detailFacts.package_width_cm,
      package_height_cm: detailFacts.package_height_cm,
      volumetric_weight_kg: detailFacts.volumetric_weight_kg,
      dimensions_display: detailFacts.dimensions_display,
      weight_basis: detailFacts.weight_g ? "1688_source" : "",
      scrape_status: weightComplete && allDimensionsComplete ? "ok" : "partial",
      error_message: errors.join("；"),
      collected_at: new Date().toISOString()
    };
  }

  async function extractProduct() {
    const deadline = Date.now() + 10000;
    let lastError;
    while (Date.now() < deadline) {
      try { return await extractProductSnapshot(); }
      catch (error) {
        lastError = error;
        if (!/尚未加载|未识别到/.test(error.message || "")) throw error;
        await new Promise(resolve => setTimeout(resolve, 400));
      }
    }
    throw lastError;
  }

  async function aiWeightPriceDetail() {
    const product = await extractProduct();
    const facts = { ...product, raw_weight: product.weight_g ? `${product.weight_g}g` : "", skus: product.variations };
    const memberNode = document.querySelector("[data-member-id], [data-company-id], a[href*='memberId']");
    return {
      ...product,
      url: location.href,
      merchant_id: memberNode?.getAttribute("data-member-id")
        || memberNode?.getAttribute("data-company-id") || "",
      raw_weight: facts.raw_weight,
      weight_g: facts.weight_g,
      package_length_cm: facts.package_length_cm,
      package_width_cm: facts.package_width_cm,
      package_height_cm: facts.package_height_cm,
      volumetric_weight_kg: facts.volumetric_weight_kg,
      dimensions_display: facts.dimensions_display,
      skus: facts.skus.length ? facts.skus : (product.variations || [])
    };
  }

  function aiWeightPriceSearchCandidates() {
    const result = [];
    const seen = new Set();
    const add = (node, href) => {
      const url = absoluteUrl(href || node?.href || "");
      const id = itemIdFromValue(url);
      if (!id || seen.has(id)) return;
      const card = node?.closest?.("li, .offer-item, .search-offer-wrapper, [class*='offer'], [class*='card']") || node;
      const image = card?.querySelector?.("img") || node?.querySelector?.("img");
      const titleNode = card?.querySelector?.(".title-text, [class*='title'], h3, h4");
      const title = String(titleNode?.textContent || node?.getAttribute?.("title") || image?.alt || "")
        .replace(/\s+/g, " ").trim();
      if (!title && !image) return;
      seen.add(id);
      result.push({
        source_item_id: id, url: url || `https://detail.1688.com/offer/${id}.html`,
        title: title.slice(0, 500),
        main_image_url: absoluteImage(image?.currentSrc || image?.src || image?.dataset?.src || ""),
        image_url: absoluteImage(image?.currentSrc || image?.src || image?.dataset?.src || ""),
        price: aiWeightPriceNumber(card?.querySelector?.("[class*='price'], .price-item")?.textContent || "")
      });
    };
    document.querySelectorAll("a[href*='/offer/'], a[href*='offerId='], a[data-key-value*='offer_']")
      .forEach(node => add(node, node.href));
    document.querySelectorAll("img").forEach(image => {
      const card = image.closest("a[href*='/offer/'], li, .offer-item, .search-offer-wrapper, [class*='offer'], [class*='card']");
      if (card) add(card, card.href || card.querySelector?.("a[href]")?.href);
    });
    return result.slice(0, 30);
  }

  function aiWeightPriceClickSearchButton() {
    const nodes = [...document.querySelectorAll("button, a, input[type='button'], input[type='submit'], [role='button']")];
    const node = nodes.find(item => /以图搜货|图片搜索|上传图片|找同款|相似货源|搜索货源/i.test(
      String(item.textContent || item.value || item.getAttribute("aria-label") || "")
    ));
    if (node) { node.click(); return true; }
    return false;
  }

  function aiWeightPriceSelectorNode(selector) {
    if (!selector) return null;
    try { return document.querySelector(selector); } catch (_) { return null; }
  }

  async function aiWeightPriceSearch(data = {}) {
    const selectors = data.selectors || {};
    let input = aiWeightPriceSelectorNode(selectors.image_search_upload) || document.querySelector("input[type='file']");
    if (!input) {
      const open = aiWeightPriceSelectorNode(selectors.image_search_open);
      if (open) open.click(); else aiWeightPriceClickSearchButton();
      await new Promise(resolve => setTimeout(resolve, 500));
      input = aiWeightPriceSelectorNode(selectors.image_search_upload) || document.querySelector("input[type='file']");
    }
    if (data.data_url) {
      if (input) {
        const [meta, encoded] = String(data.data_url).split(",", 2);
        const mime = meta.match(/data:([^;]+)/i)?.[1] || "image/jpeg";
        const binary = atob(encoded || "");
        const bytes = new Uint8Array(binary.length);
        for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
        const transfer = new DataTransfer();
        transfer.items.add(new File([bytes], "zeshun-search.jpg", {type: mime}));
        input.files = transfer.files;
        input.dispatchEvent(new Event("change", {bubbles: true}));
      }
    }
    const submit = aiWeightPriceSelectorNode(selectors.image_search_submit);
    if (submit) submit.click(); else aiWeightPriceClickSearchButton();
    const deadline = Date.now() + Math.max(3000, Number(data.timeout_ms || 15000));
    let candidates = [];
    while (Date.now() < deadline) {
      await new Promise(resolve => setTimeout(resolve, 700));
      candidates = aiWeightPriceSearchCandidates();
      if (candidates.length) break;
    }
    return candidates;
  }

  function showToast(message, kind = "success") {
    let toast = document.querySelector(".zeshun-collector-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "zeshun-collector-toast";
      document.documentElement.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = `zeshun-collector-toast is-${kind}`;
    requestAnimationFrame(() => toast.classList.add("is-visible"));
    window.clearTimeout(Number(toast.dataset.timer || 0));
    toast.dataset.timer = String(window.setTimeout(() => toast.classList.remove("is-visible"), 3200));
  }

  async function collectFromPage(button) {
    button.disabled = true;
    const original = button.textContent;
    button.textContent = "正在采集…";
    try {
      const response = await chrome.runtime.sendMessage({type: "SUBMIT_PRODUCT", product: await extractProduct()});
      if (!response?.ok) throw new Error(response?.error || "采集失败");
      showToast(response.queued ? "控制台暂不可用，商品已加入待传队列" : "已采集到 AI 原创产品", response.queued ? "warning" : "success");
      button.textContent = "采集成功 ✓";
      window.setTimeout(() => { button.textContent = original; }, 1800);
    } catch (error) {
      showToast(error.message || String(error), "error");
      button.textContent = original;
    } finally {
      button.disabled = false;
    }
  }

  async function collectFromList(button, product) {
    button.disabled = true;
    const original = button.textContent;
    button.textContent = "采集中…";
    try {
      const response = await chrome.runtime.sendMessage({type: "SUBMIT_PRODUCT", product});
      if (!response?.ok) throw new Error(response?.error || "采集失败");
      showToast(
        response.queued ? "控制台暂不可用，商品已加入待传队列" : "商品已采集到 AI 原创产品",
        response.queued ? "warning" : "success"
      );
      button.textContent = response.queued ? "已待传" : "已采集 ✓";
    } catch (error) {
      showToast(error.message || String(error), "error");
      button.textContent = "重试";
    } finally {
      window.setTimeout(() => {
        button.disabled = false;
        button.textContent = original;
      }, 1800);
    }
  }

  function mountCollectorButton() {
    if (!itemId() || document.querySelector(".zeshun-collector-floating")) return;
    const host = document.createElement("div");
    host.className = "zeshun-collector-floating";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "zeshun-collector-primary";
    button.textContent = "采集到泽顺";
    button.addEventListener("click", () => collectFromPage(button));
    host.appendChild(button);
    document.documentElement.appendChild(host);
  }

  function mountListButtons() {
    if (location.hostname !== "s.1688.com") return;
    document.querySelectorAll(".search-offer-wrapper").forEach(card => {
      if (card.querySelector(".zeshun-card-collect")) return;
      const product = listCardCandidate(card);
      if (!product) return;
      card.classList.add("zeshun-collector-card-host");
      const button = document.createElement("button");
      button.type = "button";
      button.className = "zeshun-card-collect";
      button.textContent = "采集";
      button.title = "快速采集到泽顺 AI 原创产品";
      button.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        const current = listCardCandidate(card);
        if (!current) return showToast("商品列表已变化，请刷新后重试", "error");
        collectFromList(button, current);
      });
      card.appendChild(button);
    });
  }

  function refreshUi() {
    mountCollectorButton();
    mountListButtons();
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "PING_PAGE") {
      sendResponse({ok: true, detail: Boolean(itemId()), platform: "1688"});
      return;
    }
    if (message?.type === "EXTRACT_PRODUCT") {
      extractProduct().then(product => sendResponse({ok: true, product}))
        .catch(error => sendResponse({ok: false, error: error.message || String(error)}));
      return true;
    }
    if (message?.type === "AI_WEIGHT_PRICE_READ_DETAIL") {
      aiWeightPriceDetail().then(detail => sendResponse({ok: true, detail}))
        .catch(error => sendResponse({ok: false, error: error.message || String(error)}));
      return true;
    }
    if (message?.type === "AI_WEIGHT_PRICE_SEARCH") {
      aiWeightPriceSearch(message).then(candidates => sendResponse({ok: true, candidates})).catch(error => {
        sendResponse({ok: false, error: error.message || String(error)});
      });
      return true;
    }
  });

  const observer = new MutationObserver(() => {
    window.clearTimeout(mutationTimer);
    mutationTimer = window.setTimeout(refreshUi, 180);
  });
  observer.observe(document.documentElement, {childList: true, subtree: true});
  refreshUi();
})();
