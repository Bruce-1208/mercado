(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.ZeshunMercadoData = api;
})(globalThis, function() {
  'use strict';
  function listingId(url) {
    let value = String(url || '');
    try { value = decodeURIComponent(value); } catch (_) {}
    const explicit = value.match(/(?:item_id|itemId|wid)=((?:MLM|MLB|MLC|MLA|MLU|MCO)-?\d{5,})/i);
    if (explicit) return explicit[1].replace('-', '').toUpperCase();
    if (/\/p\/|\/up\//i.test(value)) return ''; // A catalog ID is not a seller listing.
    return (value.match(/\b(?:MLM|MLB|MLC|MLA|MLU|MCO)-?\d{5,}\b/i)?.[0] || '').replace('-', '').toUpperCase();
  }
  function apply(product, record) {
    if (!record?.product) throw Error('数据源尚无该商品记录，请稍后重试');
    const info = record.product;
    if (info.sku !== product.source_item_id) throw Error('商品编号与数据响应不一致');
    const size = info.size_cm || [];
    const complete = info.weight_g > 0 && size.length === 3 && size.every(v => v > 0);
    Object.assign(product, {
      weight_g: info.weight_g, package_length_cm:size[0] ?? null,
      package_width_cm:size[1] ?? null, package_height_cm:size[2] ?? null,
      volumetric_weight_kg: info.volumetric_weight_g == null ? null : info.volumetric_weight_g / 1000,
      weight_basis:'server_actual', net_proceeds_usd:info.net_proceeds_usd,
      commission_amount_usd:info.commission_amount_usd,
      scrape_status:complete && product.main_image_url ? 'ok' : 'partial',
      error_message:!complete ? '商品数据暂缺实际重量或完整包装尺寸' : !product.main_image_url ? '未识别到商品主图' : '',
      plugin_snapshot:{...info, source:'泽顺商品数据服务', read_method:'zeshun_server_api',
        fetched_at:record.fetched_at, weight_basis:'server_actual',
        fulfillment_type:info.fulfillment_type, fulfillment_label:info.fulfillment_label,
        fulfillment_eligible:info.fulfillment_eligible, self_ship_origin:info.seller_country || 'unknown',
        sales:info.sales, volumetric_formula:'length_cm * width_cm * height_cm / 6000'}
    });
    product.source.sold_quantity = info.sales;
    return product;
  }
  function rows(info, now = Date.now()) {
    const display = v => v === null || v === undefined || v === '' ? '—' : String(v);
    const money = v => v === null || v === undefined ? '—' : `$${Number(v).toFixed(2)}`;
    const listed = info.listed_at ? String(info.listed_at).slice(0, 10) : '';
    const days = listed ? Math.floor((now - Date.parse(listed+'T00:00:00Z'))/86400000) : NaN;
    const age = Number.isFinite(days) && days >= 0 ? `（${days}天前）` : '';
    return [
      ['商品', `${info.sku} · ${display(info.seller_country)} · ${info.fulfillment_label}`],
      ['卖家', `${display(info.seller)}${info.seller_level != null ? ` · ${info.seller_level}_GREEN` : ''}${info.seller_status ? ` · ${info.seller_status}` : ''}`],
      ['销量 / 佣金', `${display(info.sales)} / ${info.commission_percent == null ? '—' : info.commission_percent+'%'}`],
      ['品牌', display(info.brand)],
      ['重量', `${info.weight_g == null ? '—' : info.weight_g+'g'} · 运费 ${money(info.weight_freight_usd)}${info.effective_freight_source === 'weight' ? ' ✓' : ''}`],
      ['尺寸', `${info.size_cm ? info.size_cm.join(' × ')+' cm' : '—'}（计抛${display(info.volumetric_weight_g)}g）`],
      ['体积运费', `${money(info.size_freight_usd)}${info.effective_freight_source === 'size' ? ' ✓' : ''}${info.low_freight ? ' · 低价档' : ''}`],
      ['上架', listed ? listed+age : '—'],
      ['预计净收益', `${money(info.net_proceeds_usd)} / ${info.net_proceeds_cny == null ? '—' : '¥'+Number(info.net_proceeds_cny).toFixed(2)}`]
    ];
  }
  return {listingId, apply, rows};
});
