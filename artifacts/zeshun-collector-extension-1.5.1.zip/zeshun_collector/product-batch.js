"use strict";

// Runs in the extension service worker, independently of the popup's lifetime.
const PRODUCT_BATCH_KEY = "productBatch";
const PRODUCT_SEARCH_HOSTS = {
  MLM: "listado.mercadolibre.com.mx", MLB: "lista.mercadolivre.com.br",
  MLA: "listado.mercadolibre.com.ar", MLC: "listado.mercadolibre.cl",
  MCO: "listado.mercadolibre.com.co", MLU: "listado.mercadolibre.com.uy"
};
const INTERNATIONAL_FILTER = "_NoIndex_True_SHIPPING*ORIGIN_10215069";
let productBatchRun = null;
let productBatchStarting = false;

function productBatchUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password ||
      !/(^|\.)(mercadolibre\.com\.(mx|br|ar|co|uy)|mercadolivre\.com\.br|mercadolibre\.cl)$/i.test(url.hostname)) {
    throw new Error("请选择支持的 Mercado Libre 前端页面");
  }
  url.hash = "";
  return url.href;
}

function hasInternationalFilter(value) {
  let decoded = String(value || "");
  try { decoded = decodeURIComponent(decoded); } catch (_) {}
  return /SHIPPING(?:\*|_)?ORIGIN(?:_|=)10215069/i.test(decoded);
}

function forceInternationalUrl(value) {
  const url = new URL(productBatchUrl(value));
  if (!hasInternationalFilter(url.href)) {
    url.pathname = `${url.pathname.replace(/\/$/, "")}${INTERNATIONAL_FILTER}`;
  }
  return url.href;
}

function productSearchUrl(country, keyword) {
  const host = PRODUCT_SEARCH_HOSTS[String(country || "").toUpperCase()];
  const text = String(keyword || "").replace(/\s+/g, " ").trim();
  if (!host) throw new Error("请选择支持的国家");
  if (!text) throw new Error("请输入采集关键词");
  if (text.length > 160) throw new Error("采集关键词不能超过 160 个字符");
  return `https://${host}/${encodeURIComponent(text.replace(/\s+/g, "-"))}${INTERNATIONAL_FILTER}`;
}

function productBatchParams(params = {}) {
  const read = (key, label, max) => {
    const value = Number(params[key]);
    if (!Number.isInteger(value) || value < 1 || value > max) throw new Error(`${label}须为 1–${max} 的整数`);
    return value;
  };
  return {
    max_items: read("max_items", "采集数量", 500),
    concurrency: read("concurrency", "并发数", 10)
  };
}

async function getProductBatchStatus() {
  if (productBatchRun) return {...productBatchRun.state};
  const stored = await storageGet("local", [PRODUCT_BATCH_KEY]);
  const state = stored[PRODUCT_BATCH_KEY] || {running: false, message: "等待启动"};
  if (state.running) {
    state.running = false;
    state.phase = "interrupted";
    state.message = "浏览器或插件已重启，任务中断；已上传的商品保留，请重新启动。";
    await storageSet("local", {[PRODUCT_BATCH_KEY]: state});
  }
  return state;
}

async function saveProductBatch(run) {
  const snapshot = {...run.state};
  run.saving = (run.saving || Promise.resolve()).then(() =>
    storageSet("local", {[PRODUCT_BATCH_KEY]: snapshot})
  );
  await run.saving;
}

async function closeProductBatchTab(run, id) {
  if (!run.tabs.delete(id)) return;
  try { await chrome.tabs.remove(id); } catch (_) {}
}

async function readProductBatchPage(run, url, type, consume) {
  if (run.stop) return null;
  const tab = await chrome.tabs.create({url: productBatchUrl(url), active: false});
  run.tabs.add(tab.id);
  try {
    const deadline = Date.now() + 45000;
    let response;
    let lastError = "页面未加载完成";
    while (!run.stop && Date.now() < deadline) {
      const current = await chrome.tabs.get(tab.id);
      if (current.status === "complete") {
        try { productBatchUrl(current.url); } catch (_) {
          throw new Error("页面跳转到登录或验证地址，请先在前端页面完成验证");
        }
        try { response = await sendTabMessage(tab.id, {type}); }
        catch (error) { lastError = error.message; }
        if (response?.blocked) throw new Error(response.error || "请先完成登录或人机验证");
        if (response?.ok) return await consume(response);
        if (response?.error) lastError = response.error;
      }
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    if (!run.stop) throw new Error(`页面读取超时：${lastError}`);
    return null;
  } finally {
    await closeProductBatchTab(run, tab.id);
  }
}

async function runProductBatch(run) {
  const {params} = run.state;
  const visited = new Set();
  const seen = new Set();
  const uploaded = new Set();
  let url = run.state.source_url;
  let pagesRead = 0;
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  try {
    while (!run.stop && url && run.state.candidate_count < params.max_items) {
      url = forceInternationalUrl(url);
      if (visited.has(url)) throw new Error("翻页链接重复，已停止以避免重复采集");
      visited.add(url);
      const listing = await readProductBatchPage(run, url, "READ_PRODUCT_LIST", value => value);
      if (!listing || run.stop) break;
      pagesRead += 1;
      if (pagesRead > 100) throw new Error("本次最多读取 100 页，请缩小采集数量");
      if (!listing.international_selected) throw new Error("Mercado 未成功进入 Internacional，采集任务已停止");
      const page = Number(listing.page);
      if (!Number.isInteger(page) || page < 1) throw new Error("无法识别当前列表页码");
      run.state.current_page = page;
      run.state.message = `正在采集第 ${page} 页（Internacional · 并发 ${params.concurrency}）`;
      await saveProductBatch(run);

      const candidates = [];
      for (const item of listing.items || []) {
        const itemUrl = productBatchUrl(item.url);
        const key = item.key || itemUrl;
        if (seen.has(key)) continue;
        seen.add(key);
        if (!item.eligible || item.isUsOrigin || (!item.isChinaOrigin && !item.isManaged)) {
          run.state.skipped += 1;
          continue;
        }
        if (run.state.candidate_count >= params.max_items) break;
        run.state.candidate_count += 1;
        candidates.push(itemUrl);
      }

      let index = 0;
      await Promise.all(Array.from({length: Math.min(params.concurrency, candidates.length)}, async () => {
        while (!run.stop && index < candidates.length) {
          const itemUrl = candidates[index++];
          try {
            await readProductBatchPage(run, itemUrl, "EXTRACT_BATCH_PRODUCT", async response => {
              if (run.stop) return;
              const product = response.product;
              run.state.current_item_id = product.source_item_id || "";
              if (uploaded.has(product.source_item_id)) { run.state.skipped += 1; return; }
              uploaded.add(product.source_item_id);
              await uploadProduct(product, {openConsole: false});
              run.state.completed_count += 1;
            });
          } catch (error) {
            if (!run.stop) {
              run.state.failed_count += 1;
              run.state.last_error = error.message || String(error);
              if (error.authRequired) { run.error = error; run.stop = true; }
            }
          }
          run.state.processed_count = run.state.completed_count + run.state.failed_count;
          await saveProductBatch(run);
        }
      }));
      if (run.state.candidate_count >= params.max_items) break;
      url = listing.next_url;
    }
    if (run.error) throw run.error;
    run.state.phase = run.stop ? "stopped" : (run.state.failed_count ? "partial" : "completed");
    run.state.message = run.stop ? "已停止采集" : "采集结束（已达到采集数量或 Internacional 搜索末页）";
  } catch (error) {
    run.state.phase = run.stop && !run.error ? "stopped" : "error";
    run.state.message = run.state.phase === "stopped" ? "已停止采集" : error.message || String(error);
  } finally {
    clearInterval(keepAlive);
    await Promise.all([...run.tabs].map(id => closeProductBatchTab(run, id)));
    run.state.running = false;
    run.state.finished_at = Date.now();
    await saveProductBatch(run);
    productBatchRun = null;
  }
}

async function startProductBatch(message) {
  if (productBatchRun || productBatchStarting) throw new Error("美客多采集任务正在运行，请先停止当前任务");
  productBatchStarting = true;
  try {
    if (!await authSession()) throw new Error("请先在插件设置中登录泽顺控制台账号");
    const params = productBatchParams(message.params);
    const tab = await chrome.tabs.get(Number(message.tab_id));
    const originalUrl = productBatchUrl(tab.url);
    const pageContext = await sendTabMessage(tab.id, {type: "READ_PRODUCT_LIST"});
    if (!pageContext.ok) throw new Error(pageContext.error || "请选择已加载完成的 Mercado Libre 搜索列表页");
    const zying = await sendTabMessage(tab.id, {type: "CHECK_ZYING_PLUGIN"});
    if (!zying?.logged_in) throw new Error(zying?.message || "无法确认智赢插件登录状态");
    const run = {tabs: new Set(), stop: false, state: {
      running: true, phase: "running", params,
      source_url: forceInternationalUrl(originalUrl),
      zying_logged_in: true, candidate_count: 0, processed_count: 0,
      completed_count: 0, failed_count: 0, skipped: 0, current_page: 0,
      current_item_id: "", started_at: Date.now(), message: "正在进入 Internacional 国际卖家专区"
    }};
    await saveProductBatch(run);
    productBatchRun = run;
    void runProductBatch(run);
    return {...run.state};
  } finally { productBatchStarting = false; }
}

async function stopProductBatch() {
  const run = productBatchRun;
  if (run) {
    run.stop = true;
    run.state.message = "正在停止，等待正在上传的商品完成…";
    await saveProductBatch(run);
    await Promise.all([...run.tabs].map(id => closeProductBatchTab(run, id)));
  }
  return getProductBatchStatus();
}
