"use strict";

// Runs in the extension service worker, independently of the popup's lifetime.
const PRODUCT_BATCH_KEY = "productBatch";
const PRODUCT_READ_TIMEOUT_MS = 30000;
const PRODUCT_DETAIL_TIMEOUT_MS = 90000;
const PRODUCT_CONNECT_TIMEOUT_MS = 15000;
const PRODUCT_SEARCH_HOSTS = {
  MLM: "listado.mercadolibre.com.mx", MLB: "lista.mercadolivre.com.br",
  MLA: "listado.mercadolibre.com.ar", MLC: "listado.mercadolibre.cl",
  MCO: "listado.mercadolibre.com.co", MLU: "listado.mercadolibre.com.uy"
};
const INTERNATIONAL_FILTER = "_NoIndex_True_SHIPPING*ORIGIN_10215069";
let productBatchRun = null;
let productBatchStarting = false;

function reportProductBatchAttention(message, context = {}) {
  if (typeof notifyAttention !== "function") return;
  void notifyAttention(message, context).catch(() => {});
}

function productBatchUrl(value) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password ||
      !/(^|\.)(mercadolibre\.com\.(mx|br|ar|co|uy)|mercadolivre\.com\.br|mercadolibre\.cl)$/i.test(url.hostname)) {
    throw new Error("请选择支持的 Mercado Libre 前端页面");
  }
  url.hash = "";
  return url.href;
}

function hasInternationalFilter(value) {
  let decoded = String(value || "");
  try { decoded = decodeURIComponent(decoded); } catch (_) {}
  return /SHIPPING(?:\*|_)?ORIGIN(?:_|=)10215069/i.test(decoded);
}

function forceInternationalUrl(value) {
  const url = new URL(productBatchUrl(value));
  if (!hasInternationalFilter(url.href)) {
    url.pathname = `${url.pathname.replace(/\/$/, "")}${INTERNATIONAL_FILTER}`;
  }
  return url.href;
}

function productSearchUrl(country, keyword) {
  const host = PRODUCT_SEARCH_HOSTS[String(country || "").toUpperCase()];
  const text = String(keyword || "").replace(/\s+/g, " ").trim();
  if (!host) throw new Error("请选择支持的国家");
  if (!text) throw new Error("请输入采集关键词");
  if (text.length > 160) throw new Error("采集关键词不能超过 160 个字符");
  return `https://${host}/${encodeURIComponent(text.replace(/\s+/g, "-"))}${INTERNATIONAL_FILTER}`;
}

function normalizeManagementCategoryId(value) {
  if (value === null || value === undefined || value === "" ||
      (typeof value === "string" && !value.trim())) return null;
  const validType = typeof value === "number" ||
    (typeof value === "string" && /^\d+$/.test(value.trim()));
  const id = Number(value);
  if (!validType || !Number.isSafeInteger(id) || id <= 0) {
    throw Object.assign(new Error("请选择有效的泽顺产品分类"), {nonRetryable: true});
  }
  return id;
}

function assertManagementCategorySession(auth, categoryId = true) {
  if (categoryId && auth?.mode === "legacy") {
    throw Object.assign(new Error("请更新泽顺服务端并在插件设置中重新登录后使用分类采集"), {nonRetryable: true});
  }
}

function productBatchParams(params = {}) {
  const read = (key, label, max) => {
    const value = Number(params[key]);
    if (!Number.isInteger(value) || value < 1 || value > max) throw new Error(`${label}须为 1–${max} 的整数`);
    return value;
  };
  const optionalSales = (key, label) => {
    if (params[key] === "" || params[key] === null || params[key] === undefined) return null;
    const value = Number(params[key]);
    if (!Number.isInteger(value) || value < 0 || value > 1000000000) throw new Error(`${label}须为 0–1000000000 的整数`);
    return value;
  };
  const minSales = optionalSales("min_sales", "最低销量");
  const maxSales = optionalSales("max_sales", "最高销量");
  if (minSales !== null && maxSales !== null && maxSales < minSales) {
    throw new Error("最高销量不能低于最低销量");
  }
  const concurrencyMode = String(params.concurrency_mode || "normal");
  if (!["gentle", "normal"].includes(concurrencyMode)) {
    throw new Error("请选择缓和模式或普通模式");
  }
  const concurrency = Number(params.concurrency ?? (concurrencyMode === "gentle" ? 1 : 3));
  if (!Number.isInteger(concurrency) || concurrency < 1 || concurrency > 5) {
    throw new Error("采集进程数须为 1–5 的整数");
  }
  const restSeconds = Number(params.success_rest_seconds ?? 0);
  if (!Number.isFinite(restSeconds) || restSeconds < 0 || restSeconds > 3600) {
    throw new Error("成功后休息时间须为 0–3600 秒");
  }
  return {
    price_mode: params.price_mode === "discount" ? "discount" : "original",
    success_rest_seconds: restSeconds,
    max_items: read("max_items", "采集数量", 500),
    concurrency_mode: concurrency === 1 ? "gentle" : "normal",
    concurrency,
    min_sales: minSales,
    max_sales: maxSales,
    management_category_id: normalizeManagementCategoryId(params.management_category_id)
  };
}

function productBatchEligibility(product, params) {
  const snapshot = product && product.plugin_snapshot || {};
  const fulfillment = String(snapshot.fulfillment_type || "unknown");
  if (!snapshot.fulfillment_eligible || !["self_ship", "semi_managed"].includes(fulfillment)) {
    return {eligible: false, reason: `泽顺商品数据发货方式：${snapshot.fulfillment_label || "未识别"}`};
  }
  const rawSales = snapshot.sales;
  const sales = Number(rawSales);
  const hasSales = rawSales !== null && rawSales !== undefined && rawSales !== "" &&
    Number.isFinite(sales) && sales >= 0;
  if ((params.min_sales !== null || params.max_sales !== null) && !hasSales) {
    return {eligible: false, reason: "泽顺商品数据销量未读取到"};
  }
  if (params.min_sales !== null && sales < params.min_sales) {
    return {eligible: false, reason: `泽顺商品数据销量 ${sales} 低于 ${params.min_sales}`};
  }
  if (params.max_sales !== null && sales > params.max_sales) {
    return {eligible: false, reason: `泽顺商品数据销量 ${sales} 高于 ${params.max_sales}`};
  }
  return {eligible: true, sales: hasSales ? sales : null};
}

async function getProductBatchStatus() {
  if (productBatchRun) return {...productBatchRun.state};
  const stored = await storageGet("local", [PRODUCT_BATCH_KEY]);
  const state = stored[PRODUCT_BATCH_KEY] || {running: false, message: "等待启动"};
  if (state.running) {
    state.running = false;
    state.phase = "interrupted";
    state.message = "浏览器或插件已重启，任务中断；已上传的商品保留，请重新启动。";
    await storageSet("local", {[PRODUCT_BATCH_KEY]: state});
  }
  return state;
}

async function saveProductBatch(run) {
  const snapshot = {...run.state};
  run.saving = (run.saving || Promise.resolve()).catch(() => {}).then(() =>
    productBatchReadWithin(() => storageSet("local", {[PRODUCT_BATCH_KEY]: snapshot}), Date.now() + 3000, undefined, "保存采集进度")
  ).catch(() => { /* Keep in-memory progress usable if browser storage stalls. */ });
  await run.saving;
}

async function closeProductBatchTab(run, id) {
  if (!run.tabs.delete(id)) return;
  try { await productBatchReadWithin(() => chrome.tabs.remove(id), Date.now() + 3000); } catch (_) {}
}

async function createProductBatchWindow() {
  if (!chrome.windows || !chrome.windows.create) {
    throw new Error("当前 Edge 不支持创建独立采集窗口，请更新浏览器后重试");
  }
  const created = await chrome.windows.create({
    url: "about:blank",
    type: "normal",
    focused: false,
    width: 640,
    height: 480
  });
  if (!created || !created.id) throw new Error("无法创建独立采集窗口");
  return created;
}

async function closeProductBatchWindow(run) {
  const windowId = run && run.windowId;
  if (!windowId) return;
  run.windowId = null;
  try {
    if (chrome.windows && chrome.windows.remove) await productBatchReadWithin(() => chrome.windows.remove(windowId), Date.now() + 3000);
  } catch (_) {}
}

function productBatchTabUrl(tab) {
  const candidates = [tab && tab.pendingUrl, tab && tab.url]
    .map(value => String(value || "").trim())
    .filter(Boolean);
  let invalidUrl = "";
  for (const value of candidates) {
    // During a new tab navigation Chromium may expose about:blank (or an
    // internal error page) in `url` while the real destination is still in
    // `pendingUrl`. Keep polling instead of treating that short transition as
    // a login or verification redirect.
    if (/^(?:about:blank|chrome(?:-error)?:\/\/|edge(?:-error)?:\/\/|view-source:)/i.test(value)) {
      continue;
    }
    try {
      return productBatchUrl(value);
    } catch (_) {
      invalidUrl = value;
    }
  }
  if (invalidUrl) {
    throw new Error("页面跳转到登录或验证地址，请先在前端页面完成验证");
  }
  return "";
}

function productBatchBlockReason(response) {
  if (response?.errorSource === "data_service" || response?.authRequired) return "";
  const text = String(response?.error || response?.message || "");
  if (Number(response?.status) === 429 || /限频|访问(?:过于)?频繁|请求(?:过于)?频繁|操作频繁|too many requests|rate.?limit|HTTP\s*429/i.test(text)) return "美客多访问限频";
  if (response?.blocked || (!/泽顺商品数据/.test(text) && /买家.*登录|登录或.*验证|account.?verification/i.test(text))) return "需要美客多买家账号登录或完成验证";
  return "";
}

async function pauseProductBatchForBlock(run, reason) {
  if (reason === "美客多访问限频") {
    run.stop = true;
    run.stopReason = "美客多访问限频，任务已自动停止；已采集成功的商品保留，请稍后手动启动。";
    run.state.phase = "stopped";
    run.state.retry_at = null;
    run.state.message = run.stopReason;
    reportProductBatchAttention(run.stopReason, {source: "美客多商品采集"});
    await saveProductBatch(run);
    return;
  }
  // Only a blocked search page is a batch-level failure. Detail pages are
  // isolated below; never reset their deadlines or suspend unrelated lanes.
  run.stop = true;
  run.stopReason = `${reason}，列表页无法继续，任务已停止；已采集成功的商品保留，完成验证后可重新启动。`;
  run.state.phase = "stopped";
  run.state.retry_at = null;
  run.state.message = run.stopReason;
  reportProductBatchAttention(run.stopReason, {source: "美客多商品采集"});
  await saveProductBatch(run);
}

function productBatchReadWithin(action, deadline, run, stage = "浏览器操作") {
  let timer, stopTimer;
  return Promise.race([
    Promise.resolve().then(action),
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${stage}响应超时`)), Math.max(0, deadline - Date.now()));
      if (run) stopTimer = setInterval(() => {
        if (run.stop) reject(new Error(run.stopReason || "已停止采集"));
      }, 100);
    })
  ]).finally(() => { clearTimeout(timer); clearInterval(stopTimer); });
}

async function readProductBatchPage(run, url, type, consume) {
  if (run.stop) return null;
  // Selecting a tab in our own window does not focus that window. Otherwise
  // the initial about:blank tab stays selected throughout the entire batch.
  const tabOptions = {url: productBatchUrl(url), active: Boolean(run.windowId)};
  if (type === "EXTRACT_BATCH_PRODUCT" && typeof prefetchMercadoProduct === "function") prefetchMercadoProduct(tabOptions.url);
  if (run.windowId) tabOptions.windowId = run.windowId;
  let abandoned = false;
  let tab;
  try {
    tab = await productBatchReadWithin(async () => {
      const created = await chrome.tabs.create(tabOptions);
      if (abandoned || run.stop) {
        run.tabs.add(created.id);
        void closeProductBatchTab(run, created.id);
      }
      return created;
    }, Date.now() + PRODUCT_READ_TIMEOUT_MS, run, "打开美客多页面");
  } catch (error) { abandoned = true; throw error; }
  run.tabs.add(tab.id);
  try {
    const poll = async () => {
      const timeoutMs = type === "EXTRACT_BATCH_PRODUCT" ? PRODUCT_DETAIL_TIMEOUT_MS : PRODUCT_READ_TIMEOUT_MS;
      const deadline = Date.now() + timeoutMs;
      let lastError = "页面未加载完成";
      let disconnectedSince = Date.now();
      let repairAttempts = 0;
      let lastRepairAt = 0;
      let repairError = "";
      while (!run.stop && Date.now() < deadline) {
        const current = await productBatchReadWithin(() => chrome.tabs.get(tab.id), deadline, run, "读取美客多标签页状态");
        let currentUrl;
        try {
          if (/\/(?:login|registration|account-verification|challenge|captcha)(?:[/?]|$)/i.test(current.pendingUrl || current.url || "")) throw new Error("买家登录验证");
          currentUrl = productBatchTabUrl(current);
        } catch (error) {
          if (type === "EXTRACT_BATCH_PRODUCT") throw new Error("该商品需要买家登录或验证，已跳过，请完成验证后单独重试");
          await pauseProductBatchForBlock(run, "需要美客多买家账号登录或完成验证");
          return null;
        }
        if (disconnectedSince !== null && Date.now() - disconnectedSince >= PRODUCT_CONNECT_TIMEOUT_MS) {
          throw new Error(`页面采集连接超时（${PRODUCT_CONNECT_TIMEOUT_MS / 1000}秒），已释放此通道继续后续商品：${repairError || lastError}`);
        }
        if (!currentUrl) {
          lastError = "页面正在打开，等待商品页加载";
          await new Promise(resolve => setTimeout(resolve, 200));
          continue;
        }
        // Mercado 页面可能长期保持 loading（统计、推荐和浮层请求不会结束），
        // 不能把 tabs.status === complete 当作内容脚本已经可用的前置条件。
        // 直接尝试发消息，内容脚本尚未注入时只会进入下一轮重试。
        let response = null;
        try {
          response = await productBatchReadWithin(() => sendTabMessage(tab.id, {type, price_mode: run.state?.params?.price_mode || "original"}), deadline, run, type === "READ_PRODUCT_LIST" ? "读取美客多列表页" : "读取美客多详情及泽顺商品数据");
          disconnectedSince = null;
        } catch (error) {
          lastError = error.message || String(error);
          response = {status: error.status, error: lastError};
          if (/Receiving end does not exist|Could not establish connection/i.test(lastError)) {
            disconnectedSince ??= Date.now();
            // Never inject into about:blank just because pendingUrl is a
            // product URL. Only a committed, supported document is eligible.
            let committed = false;
            try { committed = Boolean(productBatchUrl(current.url)); } catch (_) {}
            if (committed && chrome.scripting?.executeScript && repairAttempts < 3 &&
                Date.now() - lastRepairAt >= 2000) {
              repairAttempts += 1;
              lastRepairAt = Date.now();
              try {
                await productBatchReadWithin(() => chrome.scripting.executeScript({
                  target: {tabId: tab.id, frameIds: [0]},
                  files: ["collector-core.js", "mercado-data.js", "content.js"],
                  injectImmediately: true
                }), Math.min(deadline, Date.now() + 3000), run, "恢复页面采集脚本");
              } catch (error) { repairError = error.message || String(error); }
            }
          }
        }
        const reason = productBatchBlockReason(response);
        if (reason) {
          if (type === "EXTRACT_BATCH_PRODUCT" && reason !== "美客多访问限频") {
            throw new Error("该商品需要买家登录或验证，已跳过，请完成验证后单独重试");
          }
          await pauseProductBatchForBlock(run, reason);
          return null;
        }
        if (response?.ok) return response;
        if (response?.authRequired || response?.retryable === false) throw Object.assign(
          new Error(response.error || "泽顺商品数据读取失败"),
          {authRequired: response.authRequired, status: response.status, errorSource: response.errorSource}
        );
        if (response?.error) lastError = response.error;
        await new Promise(resolve => setTimeout(resolve, 200));
      }
      if (!run.stop) throw new Error(`读取超时（${timeoutMs / 1000}秒）：${lastError}`);
      return null;
    };
    const response = await poll();
    return response && !run.stop ? await consume(response) : null;
  } catch (error) {
    if (!run.stop && productBatchBlockReason(error) === "美客多访问限频") {
      await pauseProductBatchForBlock(run, "美客多访问限频");
    }
    throw error;
  } finally {
    await closeProductBatchTab(run, tab.id);
  }
}

async function runProductBatch(run) {
  const {params} = run.state;
  const visited = new Set();
  const seen = new Set();
  const uploaded = new Set();
  let url = run.state.source_url;
  let pagesRead = 0;
  let candidates = [];
  let index = 0;
  let listingQueue = Promise.resolve();
  // Serialize only listing reads and candidate assignment. A free lane can
  // fetch the next page while another lane is still reading an old detail.
  const nextCandidate = () => {
    const next = listingQueue.then(async () => {
      if (run.stop || run.state.completed_count >= params.max_items) return null;
      while (index >= candidates.length) {
        if (!url || run.stop) return null;
        url = forceInternationalUrl(url);
        if (visited.has(url)) throw new Error("翻页链接重复，已停止以避免重复采集");
        if (pagesRead >= 100) throw new Error("本次最多读取 100 页，请缩小采集数量");
        visited.add(url);
        const listing = await readProductBatchPage(run, url, "READ_PRODUCT_LIST", value => value);
        if (!listing || run.stop || run.state.completed_count >= params.max_items) return null;
        pagesRead += 1;
        const page = Number(listing.page);
        if (!Number.isInteger(page) || page < 1) throw new Error("无法识别当前列表页码");
        run.state.current_page = page;
        const modeLabel = params.concurrency_mode === "gentle" ? "缓和模式" : "普通模式";
        run.state.message = listing.international_selected
          ? `正在采集第 ${page} 页（Internacional · 泽顺商品数据终审 · ${modeLabel} · ${params.concurrency} 个采集进程）`
          : `第 ${page} 页 Internacional 未生效，正逐件读取泽顺商品数据发货方式和销量`;
        await saveProductBatch(run);
        candidates = [];
        index = 0;
        for (const item of listing.items || []) {
          const itemUrl = productBatchUrl(item.url);
          const key = item.key || itemUrl;
          if (seen.has(key)) continue;
          seen.add(key);
          candidates.push(itemUrl);
        }
        // A site may ignore a synthesized offset and return the same cards.
        // Do not keep inventing URLs when that page yielded no new products.
        url = listing.next_url_synthesized && !candidates.length ? "" : listing.next_url;
      }
      return candidates[index++];
    });
    listingQueue = next.catch(error => { run.error = error; run.stop = true; });
    return next;
  };
  const keepAlive = setInterval(() => chrome.runtime.getPlatformInfo(() => {}), 20000);
  try {
    await Promise.all(Array.from({length: params.concurrency}, async (_, lane) => {
      const setLane = (stage, itemUrl = "", startedAt = Date.now()) => {
        run.state.active_items = (run.state.active_items || []).filter(item => item.lane !== lane + 1);
        if (stage) run.state.active_items.push({lane: lane + 1, stage, url: itemUrl, started_at: startedAt});
      };
      while (!run.stop && run.state.completed_count < params.max_items) {
        // Reservations may fail. Keep lanes alive until uploads settle so
        // a failed final upload cannot discard the remaining candidates.
        if (run.state.completed_count + run.reserved >= params.max_items) {
          await new Promise(resolve => setTimeout(resolve, 100));
          continue;
        }
        let itemUrl;
        try { itemUrl = await nextCandidate(); } catch (_) { break; }
        if (!itemUrl) break;
        if (run.stop) break;
        const itemStartedAt = Date.now();
        run.state.candidate_count += 1;
        setLane("读取详情", itemUrl, itemStartedAt);
        let succeeded = false;
        try {
          await readProductBatchPage(run, itemUrl, "EXTRACT_BATCH_PRODUCT", async response => {
            if (run.stop) return;
            const product = {...response.product, management_category_id: params.management_category_id};
            run.state.current_item_id = product.source_item_id || "";
            if (uploaded.has(product.source_item_id)) { run.state.skipped += 1; return; }
            const decision = productBatchEligibility(product, params);
            if (!decision.eligible) {
              run.state.skipped += 1;
              run.state.last_skip = decision.reason;
              return;
            }
            if (run.state.completed_count + run.reserved >= params.max_items) return;
            run.reserved += 1;
            uploaded.add(product.source_item_id);
            setLane("上传商品", itemUrl, itemStartedAt);
            try {
              await productBatchReadWithin(
                () => uploadProduct(product, {openConsole: false}),
                Date.now() + PRODUCT_DETAIL_TIMEOUT_MS, undefined, "上传商品到泽顺控制台"
              );
              run.state.completed_count += 1;
              const elapsedMs = Date.now() - itemStartedAt;
              run.state.last_success_ms = elapsedMs;
              run.state.total_success_ms = (run.state.total_success_ms || 0) + elapsedMs;
              run.state.over_target_count = (run.state.over_target_count || 0) + (elapsedMs >= 10000 ? 1 : 0);
              succeeded = true;
            } finally {
              run.reserved -= 1;
            }
          });
        } catch (error) {
          if (!run.stop) {
            run.state.failed_count += 1;
            run.state.last_error = `${itemUrl}：${error.message || String(error)}`;
            reportProductBatchAttention(run.state.last_error, {
              source: "美客多商品采集",
              itemId: run.state.current_item_id || ""
            });
            if (productBatchBlockReason(error) === "美客多访问限频") {
              await pauseProductBatchForBlock(run, "美客多访问限频");
            }
            if (error.authRequired) { run.error = error; run.stop = true; }
          }
        }
        setLane("");
        run.state.processed_count = run.state.completed_count + run.state.failed_count + run.state.skipped;
        await saveProductBatch(run);
        if (succeeded && !run.stop) {
          const restUntil = Date.now() + (params.success_rest_seconds ?? 0) * 1000;
          if (Date.now() < restUntil) setLane("休息", itemUrl);
          while (!run.stop && Date.now() < restUntil) {
            await new Promise(resolve => setTimeout(resolve, Math.min(100, restUntil - Date.now())));
          }
          setLane("");
        }
      }
    }));
    if (run.error) throw run.error;
    run.state.phase = run.stop ? "stopped" : (run.state.failed_count ? "partial" : "completed");
    run.state.message = run.stop ? (run.stopReason || "已停止采集") : "采集结束（已达到采集数量或搜索末页）";
  } catch (error) {
    run.state.phase = run.stop && !run.error ? "stopped" : "error";
    run.state.message = run.state.phase === "stopped" ? (run.stopReason || "已停止采集") : error.message || String(error);
    if (run.state.phase === "error") {
      reportProductBatchAttention(run.state.message, {source: "美客多商品采集"});
    }
  } finally {
    clearInterval(keepAlive);
    await Promise.all([...run.tabs].map(id => closeProductBatchTab(run, id)));
    await closeProductBatchWindow(run);
    run.state.running = false;
    run.state.active_items = [];
    run.state.finished_at = Date.now();
    await saveProductBatch(run);
    productBatchRun = null;
  }
}

async function startProductBatch(message) {
  if (productBatchRun || productBatchStarting) throw new Error("美客多采集任务正在运行，请先停止当前任务");
  productBatchStarting = true;
  let createdWindowId = null;
  try {
    const auth = await authSession();
    if (!auth) throw new Error("请先在插件设置中登录泽顺控制台账号");
    const params = productBatchParams(message.params);
    assertManagementCategorySession(auth, params.management_category_id);
    const tab = await productBatchReadWithin(() => chrome.tabs.get(Number(message.tab_id)), Date.now() + PRODUCT_READ_TIMEOUT_MS, undefined, "读取选中的美客多标签页");
    const originalUrl = productBatchUrl(tab.url);
    const pageContext = await productBatchReadWithin(() => sendTabMessage(tab.id, {type: "READ_PRODUCT_LIST"}), Date.now() + PRODUCT_READ_TIMEOUT_MS, undefined, "读取美客多起始列表页");
    if (!pageContext.ok) throw new Error(pageContext.error || "请选择已加载完成的 Mercado Libre 搜索列表页");
    const dataService = await apiRequest("/api/browser-extension/mercado-data/status");
    if (!dataService.ready) throw new Error(dataService.message || "泽顺商品数据服务未就绪");
    const run = {tabs: new Set(), windowId: null, stop: false, reserved: 0, state: {
      running: true, phase: "running", params,
      source_url: forceInternationalUrl(originalUrl),
      execution_window: "new_edge_window",
      data_service_ready: true, candidate_count: 0, processed_count: 0,
      completed_count: 0, failed_count: 0, skipped: 0, current_page: 0,
      current_item_id: "", started_at: Date.now(), message: "正在后台小窗打开搜索页，随后并发读取商品详情"
    }};
    const batchWindow = await createProductBatchWindow();
    run.windowId = batchWindow.id;
    // Keep the initial tab as an anchor: closing the sole listing tab would
    // otherwise destroy the window before the first detail is opened.
    run.placeholderTabId = batchWindow.tabs?.[0]?.id;
    if (run.placeholderTabId) run.tabs.add(run.placeholderTabId);
    createdWindowId = batchWindow.id;
    run.state.window_id = batchWindow.id;
    await saveProductBatch(run);
    productBatchRun = run;
    void runProductBatch(run);
    return {...run.state};
  } catch (error) {
    if (createdWindowId && chrome.windows && chrome.windows.remove) {
      try { await chrome.windows.remove(createdWindowId); } catch (_) {}
    }
    reportProductBatchAttention(error.message || String(error), {source: "美客多商品采集"});
    throw error;
  } finally { productBatchStarting = false; }
}

async function stopProductBatch() {
  const run = productBatchRun;
  if (run) {
    run.stop = true;
    run.state.message = "正在停止，等待正在上传的商品完成…";
    await saveProductBatch(run);
    await Promise.all([...run.tabs].map(id => closeProductBatchTab(run, id)));
  }
  return getProductBatchStatus();
}
